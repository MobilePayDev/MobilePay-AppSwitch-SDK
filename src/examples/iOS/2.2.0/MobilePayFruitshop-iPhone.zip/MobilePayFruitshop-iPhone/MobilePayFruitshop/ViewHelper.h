#import <Foundation/Foundation.h>

@interface ViewHelper : NSObject

+ (void)showAlertWithTitle:(NSString *)title message:(NSString *)message;

@end
